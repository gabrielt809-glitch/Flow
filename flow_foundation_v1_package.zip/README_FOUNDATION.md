# FLOW Foundation v1.0

Esta entrega reorganiza o app atual em uma base mais saudável para manutenção.

## Arquivos

- `index.html` — HTML principal, sem blocos gigantes de CSS/JS inline.
- `assets/styles.css` — estilos consolidados.
- `assets/app.js` — lógica consolidada + camada `FlowFoundation`.

## O que mudou

- Separação física entre HTML, CSS e JavaScript.
- Inclusão de camada `FlowFoundation` no final do JS com:
  - `FlowFoundation.State.ensure()`
  - `FlowFoundation.Storage.save()`
  - `FlowFoundation.History.syncToday()`
  - `FlowFoundation.UI.refresh()`
  - `commitApp(scope)`
- Reforço de salvamento em `visibilitychange`, `pagehide`, `beforeunload` e retorno ao foco do app.
- Manutenção do visual e funcionamento atuais.

## Observações importantes

Esta é a primeira versão Foundation. Ela ainda preserva a lógica antiga consolidada em `app.js` para reduzir risco de quebra.
A próxima etapa é remover duplicações internas dentro de `app.js`, módulo por módulo.

## Como subir no GitHub/Vercel

Suba a pasta com esta estrutura:

```txt
index.html
assets/
  styles.css
  app.js
```

A Vercel deve servir automaticamente o `index.html`.
